# Dashboard Eksekusi Leads Fleksi

Dashboard progress follow up leads Fleksi (posisi 18 vs 21 Okt 2026), dipublikasikan lewat GitHub Pages dan **dibuka dengan password**.

- Data di repository ini **terenkripsi** (`data/dashboard-data.enc.json`) dan hanya bisa dibuka dengan kunci rahasia yang disimpan di GitHub Secrets.
- Halaman website dienkripsi ulang dengan password setiap kali dipublikasikan. Tanpa password, pengunjung hanya melihat layar login.

## Mengganti password akses

1. Buka **Settings → Secrets and variables → Actions**.
2. Pada secret **`DASHBOARD_PASSWORD`**, klik ikon pensil (**Update**), isi password baru (minimal 8 karakter), lalu **Update secret**.
3. Buka tab **Actions → Publikasikan dashboard → Run workflow → Run workflow**.
4. Tunggu ±1 menit sampai tanda centang hijau. Password lama langsung tidak berlaku.

> Viewer yang sedang membuka dashboard perlu menutup tab dan membuka ulang link, lalu memasukkan password baru.

## Rahasia yang dipakai (jangan dihapus)

| Secret | Fungsi |
|---|---|
| `DASHBOARD_PASSWORD` | Password untuk membuka dashboard. Boleh diganti kapan saja. |
| `DATA_PRIVATE_KEY` | Kunci untuk membuka data terenkripsi. **Jangan diubah atau dihapus**, kecuali data juga dienkripsi ulang. |

## Memperbarui data

Data baru dienkripsi dengan `data/public_key.pem` (lihat `build/seal_data.py`) lalu menggantikan `data/dashboard-data.enc.json`. Setiap perubahan di folder `data/` otomatis mempublikasikan ulang dashboard dengan password yang berlaku.

## Isi repository

- `site/template.html` — tampilan dashboard (tanpa data).
- `data/` — data terenkripsi dan kunci publik.
- `build/` — skrip enkripsi.
- `.github/workflows/deploy.yml` — proses build & publikasi ke GitHub Pages.
